@echo off
echo Gerando o executavel (requer .NET 8 SDK apenas NESTE computador)...
dotnet publish -c Release -o publicado
echo.
echo Pronto! O programa esta em: publicado\ConversorArquivos.exe
pause
