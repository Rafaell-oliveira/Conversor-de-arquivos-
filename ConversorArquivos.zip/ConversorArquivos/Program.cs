namespace ConversorArquivos;

static class Program
{
    [STAThread]
    static void Main()
    {
        ApplicationConfiguration.Initialize();
        Application.Run(new Janela());
    }
}

static class Motor
{
    public static async Task ConverterAsync(int tipo, string origem, string destino, bool forcarOcr, Action<string> status)
    {
        switch (tipo)
        {
            case 0: // PDF -> XLSX
                {
                    var pgs = await Leitor.LerPdf(origem, forcarOcr, status);
                    Escritores.GravarXlsx(destino, pgs.Select(p => ($"Pag{p.Numero}", p.Linhas)));
                    break;
                }
            case 1: // PDF -> DOCX
                Escritores.GravarDocx(destino, await Leitor.LerPdf(origem, forcarOcr, status));
                break;
            case 2: // DOCX -> XLSX
                Escritores.GravarXlsx(destino, Escritores.LerDocx(origem));
                break;
            case 3: // Imagem -> XLSX
                {
                    var pgs = await Leitor.LerImagem(origem);
                    Escritores.GravarXlsx(destino, pgs.Select(p => ("Imagem", p.Linhas)));
                    break;
                }
            case 4: // Imagem -> DOCX
                Escritores.GravarDocx(destino, await Leitor.LerImagem(origem));
                break;
        }
    }
}

class Janela : Form
{
    static readonly (string Nome, string Filtro, string Saida)[] Tipos =
    {
        ("PDF  →  Excel (.xlsx)",            "PDF|*.pdf",                                   "xlsx"),
        ("PDF  →  Word (.docx)",             "PDF|*.pdf",                                   "docx"),
        ("Word (.docx)  →  Excel (.xlsx)",   "Word|*.docx",                                 "xlsx"),
        ("Imagem (OCR)  →  Excel (.xlsx)",   "Imagens|*.jpg;*.jpeg;*.png;*.bmp;*.tif;*.tiff", "xlsx"),
        ("Imagem (OCR)  →  Word (.docx)",    "Imagens|*.jpg;*.jpeg;*.png;*.bmp;*.tif;*.tiff", "docx"),
    };

    readonly ComboBox cbTipo = new() { DropDownStyle = ComboBoxStyle.DropDownList, Dock = DockStyle.Fill };
    readonly ListBox lista = new() { Dock = DockStyle.Fill, HorizontalScrollbar = true };
    readonly TextBox txtPasta = new() { Dock = DockStyle.Fill };
    readonly CheckBox chkOcr = new() { Text = "Forçar OCR em todas as páginas (use se o texto do PDF sair errado)", AutoSize = true };
    readonly ProgressBar barra = new() { Dock = DockStyle.Fill };
    readonly Button btnConverter = new() { Text = "Converter", Dock = DockStyle.Fill };
    readonly Label lblStatus = new() { Text = "Pronto.", AutoSize = true };
    readonly List<string> arquivos = new();

    public Janela()
    {
        Text = "Conversor de Arquivos";
        ClientSize = new Size(640, 480);
        MinimumSize = new Size(560, 440);
        Font = new Font("Segoe UI", 10f);

        foreach (var t in Tipos) cbTipo.Items.Add(t.Nome);
        cbTipo.SelectedIndex = 0;
        cbTipo.SelectedIndexChanged += (_, _) => { arquivos.Clear(); lista.Items.Clear(); };

        var btnArquivos = new Button { Text = "Selecionar arquivo(s)...", AutoSize = true };
        btnArquivos.Click += Escolher;
        var btnPasta = new Button { Text = "Pasta...", AutoSize = true };
        btnPasta.Click += (_, _) =>
        {
            using var d = new FolderBrowserDialog();
            if (d.ShowDialog() == DialogResult.OK) txtPasta.Text = d.SelectedPath;
        };
        btnConverter.Click += Converter;

        var linhaPasta = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 3, RowCount = 1, AutoSize = true };
        linhaPasta.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
        linhaPasta.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        linhaPasta.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
        linhaPasta.Controls.Add(new Label { Text = "Salvar em:", AutoSize = true, Anchor = AnchorStyles.Left }, 0, 0);
        linhaPasta.Controls.Add(txtPasta, 1, 0);
        linhaPasta.Controls.Add(btnPasta, 2, 0);

        var dica = new Label { Text = "(vazio = mesma pasta do arquivo original)", ForeColor = Color.Gray, AutoSize = true };

        var painel = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, Padding = new Padding(12) };
        painel.RowStyles.Add(new RowStyle(SizeType.AutoSize));       // tipo
        painel.RowStyles.Add(new RowStyle(SizeType.AutoSize));       // botão arquivos
        painel.RowStyles.Add(new RowStyle(SizeType.Percent, 100));   // lista
        painel.RowStyles.Add(new RowStyle(SizeType.AutoSize));       // pasta
        painel.RowStyles.Add(new RowStyle(SizeType.AutoSize));       // dica
        painel.RowStyles.Add(new RowStyle(SizeType.AutoSize));       // ocr
        painel.RowStyles.Add(new RowStyle(SizeType.Absolute, 28));   // barra
        painel.RowStyles.Add(new RowStyle(SizeType.Absolute, 42));   // botão
        painel.RowStyles.Add(new RowStyle(SizeType.AutoSize));       // status
        painel.Controls.Add(cbTipo);
        painel.Controls.Add(btnArquivos);
        painel.Controls.Add(lista);
        painel.Controls.Add(linhaPasta);
        painel.Controls.Add(dica);
        painel.Controls.Add(chkOcr);
        painel.Controls.Add(barra);
        painel.Controls.Add(btnConverter);
        painel.Controls.Add(lblStatus);
        Controls.Add(painel);
    }

    void Escolher(object? s, EventArgs e)
    {
        using var d = new OpenFileDialog { Multiselect = true, Filter = Tipos[cbTipo.SelectedIndex].Filtro };
        if (d.ShowDialog() != DialogResult.OK) return;
        arquivos.Clear(); lista.Items.Clear();
        foreach (var f in d.FileNames) { arquivos.Add(f); lista.Items.Add(f); }
    }

    static string NomeUnico(string pasta, string nome, string ext)
    {
        string cam = Path.Combine(pasta, $"{nome}.{ext}");
        for (int i = 2; File.Exists(cam); i++) cam = Path.Combine(pasta, $"{nome} ({i}).{ext}");
        return cam;
    }

    async void Converter(object? s, EventArgs e)
    {
        if (arquivos.Count == 0)
        {
            MessageBox.Show("Selecione ao menos um arquivo.", "Atenção");
            return;
        }
        btnConverter.Enabled = false;
        barra.Maximum = arquivos.Count; barra.Value = 0;
        int tipo = cbTipo.SelectedIndex;
        bool forcar = chkOcr.Checked;
        string pastaSaida = txtPasta.Text.Trim();
        int ok = 0; var erros = new List<string>();

        for (int i = 0; i < arquivos.Count; i++)
        {
            string arq = arquivos[i];
            string pasta = pastaSaida.Length > 0 ? pastaSaida : Path.GetDirectoryName(arq)!;
            string destino = NomeUnico(pasta, Path.GetFileNameWithoutExtension(arq), Tipos[tipo].Saida);
            lblStatus.Text = $"Convertendo {i + 1}/{arquivos.Count}: {Path.GetFileName(arq)}";
            try
            {
                Directory.CreateDirectory(pasta);
                await Task.Run(() => Motor.ConverterAsync(tipo, arq, destino, forcar,
                    msg => BeginInvoke(() => lblStatus.Text = msg)));
                ok++;
            }
            catch (Exception ex) { erros.Add($"{Path.GetFileName(arq)}: {ex.Message}"); }
            barra.Value = i + 1;
        }

        btnConverter.Enabled = true;
        lblStatus.Text = $"Concluído: {ok} convertido(s), {erros.Count} erro(s).";
        if (erros.Count > 0) MessageBox.Show(string.Join("\n\n", erros), "Alguns arquivos falharam");
        else MessageBox.Show($"{ok} arquivo(s) convertido(s) com sucesso!", "Pronto");
    }
}
