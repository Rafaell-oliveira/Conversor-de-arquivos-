using System.Text;
using Windows.Data.Pdf;
using Windows.Globalization;
using Windows.Graphics.Imaging;
using Windows.Media.Ocr;
using Windows.Storage;
using Windows.Storage.Streams;
using PdfPigDoc = UglyToad.PdfPig.PdfDocument;

namespace ConversorArquivos;

public record PaginaConteudo(int Numero, List<List<string>> Linhas, bool UsouOcr);
record Palavra(string Texto, double Esq, double Dir, double Topo, double Alt);

/// <summary>Lê PDFs (texto nativo + OCR automático) e imagens (OCR do Windows).</summary>
public static class Leitor
{
    static OcrEngine? _engine;

    static OcrEngine Engine()
    {
        if (_engine != null) return _engine;
        _engine = OcrEngine.TryCreateFromUserProfileLanguages();
        foreach (var tag in new[] { "pt-BR", "pt-PT", "en-US" })
        {
            if (_engine != null) break;
            var lang = new Language(tag);
            if (OcrEngine.IsLanguageSupported(lang))
                _engine = OcrEngine.TryCreateFromLanguage(lang);
        }
        if (_engine == null)
            throw new InvalidOperationException(
                "Nenhum idioma de OCR disponível no Windows. Vá em Configurações > Hora e idioma > Idioma e região e adicione Português (Brasil).");
        return _engine;
    }

    // ------------------------------------------------------------------ PDF
    public static async Task<List<PaginaConteudo>> LerPdf(string caminho, bool forcarOcr, Action<string> status)
    {
        var textos = new Dictionary<int, List<Palavra>>();
        if (!forcarOcr)
        {
            try
            {
                using var doc = PdfPigDoc.Open(caminho);
                foreach (var pg in doc.GetPages())
                {
                    double altPagina = pg.Height;
                    var ps = pg.GetWords()
                        .Select(w => new Palavra(w.Text, w.BoundingBox.Left, w.BoundingBox.Right,
                                                 altPagina - w.BoundingBox.Top, w.BoundingBox.Height))
                        .Where(p => !string.IsNullOrWhiteSpace(p.Texto))
                        .ToList();
                    textos[pg.Number] = ps;
                }
            }
            catch { /* se falhar a leitura nativa, cai para OCR */ }
        }

        PdfDocument? pdfWin = null;
        async Task<PdfDocument> Win()
        {
            if (pdfWin == null)
            {
                var arq = await StorageFile.GetFileFromPathAsync(Path.GetFullPath(caminho));
                pdfWin = await PdfDocument.LoadFromFileAsync(arq);
            }
            return pdfWin;
        }

        int total = textos.Count > 0 ? textos.Count : (int)(await Win()).PageCount;
        var paginas = new List<PaginaConteudo>();

        for (int n = 1; n <= total; n++)
        {
            if (textos.TryGetValue(n, out var ps) && ps.Sum(p => p.Texto.Length) >= 10)
            {
                paginas.Add(new PaginaConteudo(n, MontarLinhas(ps), false));
                continue;
            }
            status($"OCR na página {n} de {total}...");
            var w = await Win();
            using var page = w.GetPage((uint)(n - 1));
            var bmp = await RenderizarPagina(page);
            paginas.Add(new PaginaConteudo(n, await Reconhecer(bmp), true));
        }
        return paginas;
    }

    static async Task<SoftwareBitmap> RenderizarPagina(PdfPage page)
    {
        double escala = 3.0; // ~216 DPI, bom para OCR
        double maior = Math.Max(page.Size.Width, page.Size.Height);
        double limite = OcrEngine.MaxImageDimension;
        if (maior * escala > limite) escala = limite / maior;

        var opts = new PdfPageRenderOptions
        {
            DestinationWidth = (uint)(page.Size.Width * escala),
            DestinationHeight = (uint)(page.Size.Height * escala),
            BackgroundColor = Windows.UI.Color.FromArgb(255, 255, 255, 255)
        };
        using var ms = new InMemoryRandomAccessStream();
        await page.RenderToStreamAsync(ms, opts);
        var dec = await BitmapDecoder.CreateAsync(ms);
        return await dec.GetSoftwareBitmapAsync(BitmapPixelFormat.Bgra8, BitmapAlphaMode.Premultiplied);
    }

    // --------------------------------------------------------------- Imagem
    public static async Task<List<PaginaConteudo>> LerImagem(string caminho)
    {
        var arq = await StorageFile.GetFileFromPathAsync(Path.GetFullPath(caminho));
        using var stream = await arq.OpenAsync(FileAccessMode.Read);
        var dec = await BitmapDecoder.CreateAsync(stream);

        double maior = Math.Max(dec.PixelWidth, dec.PixelHeight);
        double esc = maior > OcrEngine.MaxImageDimension ? OcrEngine.MaxImageDimension / maior : 1.0;

        SoftwareBitmap bmp;
        if (esc < 1.0)
        {
            var tr = new BitmapTransform
            {
                ScaledWidth = (uint)(dec.PixelWidth * esc),
                ScaledHeight = (uint)(dec.PixelHeight * esc)
            };
            bmp = await dec.GetSoftwareBitmapAsync(BitmapPixelFormat.Bgra8, BitmapAlphaMode.Premultiplied,
                tr, ExifOrientationMode.RespectExifOrientation, ColorManagementMode.DoNotColorManage);
        }
        else
        {
            bmp = await dec.GetSoftwareBitmapAsync(BitmapPixelFormat.Bgra8, BitmapAlphaMode.Premultiplied);
        }
        return new List<PaginaConteudo> { new(1, await Reconhecer(bmp), true) };
    }

    // ------------------------------------------------------------------ OCR
    static async Task<List<List<string>>> Reconhecer(SoftwareBitmap bmp)
    {
        var res = await Engine().RecognizeAsync(bmp);
        var palavras = new List<Palavra>();
        foreach (var linha in res.Lines)
            foreach (var w in linha.Words)
            {
                var r = w.BoundingRect;
                palavras.Add(new Palavra(w.Text, r.X, r.X + r.Width, r.Y, r.Height));
            }
        return MontarLinhas(palavras);
    }

    // ------------------------------------- palavras -> linhas -> células
    // Lacunas largas entre palavras viram colunas (detecta tabelas simples).
    static List<List<string>> MontarLinhas(List<Palavra> palavras)
    {
        var resultado = new List<List<string>>();
        if (palavras.Count == 0) return resultado;

        double altMedia = palavras.Average(p => p.Alt);
        var linhas = new List<List<Palavra>>();

        foreach (var p in palavras.OrderBy(p => p.Topo).ThenBy(p => p.Esq))
        {
            var atual = linhas.Count > 0 ? linhas[^1] : null;
            double centro = p.Topo + p.Alt / 2;
            if (atual != null && Math.Abs(atual.Average(x => x.Topo + x.Alt / 2) - centro) < altMedia * 0.6)
                atual.Add(p);
            else
                linhas.Add(new List<Palavra> { p });
        }

        foreach (var l in linhas)
        {
            l.Sort((a, b) => a.Esq.CompareTo(b.Esq));
            var celulas = new List<string>();
            var sb = new StringBuilder(l[0].Texto);
            for (int i = 1; i < l.Count; i++)
            {
                double gap = l[i].Esq - l[i - 1].Dir;
                if (gap > altMedia * 1.2)
                {
                    celulas.Add(sb.ToString());
                    sb.Clear().Append(l[i].Texto);
                }
                else sb.Append(' ').Append(l[i].Texto);
            }
            celulas.Add(sb.ToString());
            resultado.Add(celulas);
        }
        return resultado;
    }
}
