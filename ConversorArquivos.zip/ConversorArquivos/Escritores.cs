using System.Globalization;
using ClosedXML.Excel;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using W = DocumentFormat.OpenXml.Wordprocessing;

namespace ConversorArquivos;

public static class Escritores
{
    static readonly CultureInfo PtBr = CultureInfo.GetCultureInfo("pt-BR");

    // ---------------------------------------------------------------- XLSX
    public static void GravarXlsx(string destino, IEnumerable<(string Nome, List<List<string>> Linhas)> abas)
    {
        var lista = abas.ToList();
        if (!lista.Any(a => a.Linhas.Count > 0))
            throw new InvalidOperationException("Nenhum texto foi encontrado no arquivo.");

        using var wb = new XLWorkbook();
        var usados = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        foreach (var (nome, linhas) in lista)
        {
            if (linhas.Count == 0) continue;
            var ws = wb.Worksheets.Add(NomeAba(nome, usados));
            for (int r = 0; r < linhas.Count; r++)
                for (int c = 0; c < linhas[r].Count; c++)
                {
                    var txt = linhas[r][c];
                    var cel = ws.Cell(r + 1, c + 1);
                    bool zeroEsq = txt.Length > 1 && txt[0] == '0' && char.IsDigit(txt[1]);
                    if (!zeroEsq && decimal.TryParse(txt, NumberStyles.Number, PtBr, out var d))
                        cel.Value = d;
                    else
                        cel.Value = txt;
                }
            try { ws.Columns().AdjustToContents(); } catch { }
        }
        wb.SaveAs(destino);
    }

    static string NomeAba(string nome, HashSet<string> usados)
    {
        var limpo = new string(nome.Where(ch => "[]:*?/\\".IndexOf(ch) < 0).ToArray());
        if (limpo.Length == 0) limpo = "Aba";
        if (limpo.Length > 31) limpo = limpo[..31];
        string baseNome = limpo; int i = 2;
        while (!usados.Add(limpo))
            limpo = baseNome[..Math.Min(baseNome.Length, 27)] + "_" + i++;
        return limpo;
    }

    // ---------------------------------------------------------------- DOCX
    public static void GravarDocx(string destino, List<PaginaConteudo> paginas)
    {
        if (!paginas.Any(p => p.Linhas.Count > 0))
            throw new InvalidOperationException("Nenhum texto foi encontrado no arquivo.");

        using var doc = WordprocessingDocument.Create(destino, WordprocessingDocumentType.Document);
        var main = doc.AddMainDocumentPart();
        main.Document = new W.Document();
        var body = main.Document.AppendChild(new W.Body());

        for (int i = 0; i < paginas.Count; i++)
        {
            foreach (var linha in paginas[i].Linhas)
            {
                var run = new W.Run();
                for (int k = 0; k < linha.Count; k++)
                {
                    if (k > 0) run.Append(new W.TabChar());
                    run.Append(new W.Text(linha[k]) { Space = SpaceProcessingModeValues.Preserve });
                }
                body.Append(new W.Paragraph(run));
            }
            if (i < paginas.Count - 1)
                body.Append(new W.Paragraph(new W.Run(new W.Break { Type = W.BreakValues.Page })));
        }
        main.Document.Save();
    }

    // ------------------------------------------------------- ler DOCX
    public static List<(string Nome, List<List<string>> Linhas)> LerDocx(string caminho)
    {
        using var doc = WordprocessingDocument.Open(caminho, false);
        var body = doc.MainDocumentPart?.Document?.Body
            ?? throw new InvalidOperationException("Documento Word vazio ou inválido.");

        var abas = new List<(string, List<List<string>>)>();
        int n = 1;
        foreach (var tabela in body.Elements<W.Table>())
        {
            var linhas = new List<List<string>>();
            foreach (var tr in tabela.Elements<W.TableRow>())
                linhas.Add(tr.Elements<W.TableCell>().Select(tc => tc.InnerText.Trim()).ToList());
            abas.Add(($"Tabela{n++}", linhas));
        }

        if (abas.Count == 0) // sem tabelas: um parágrafo por linha
        {
            var linhas = body.Descendants<W.Paragraph>()
                .Select(p => p.InnerText.Trim())
                .Where(t => t.Length > 0)
                .Select(t => new List<string> { t })
                .ToList();
            abas.Add(("Texto", linhas));
        }
        return abas;
    }
}
